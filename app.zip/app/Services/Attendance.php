<?php
namespace App\Services;
use Illuminate\Support\Facades\DB;


class Attendance{


}