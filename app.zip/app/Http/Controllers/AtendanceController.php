<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\Odoo;
use App\Models\Atendance;
use Illuminate\Support\Facades\DB;
class AtendanceController extends Controller
{
 
    public function index(){
        $data = DB::table('Test')->get();
        dd($data);
    }


    public function getEmployees(){

        return Odoo::getemployeeall();
    }

    public function getfields(){

        return Odoo::employeeFields();
    }

}