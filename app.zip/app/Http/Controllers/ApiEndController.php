<?php

namespace App\Http\Controllers;

use App\Models\ApiEnd;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Contact;
use App\Models\SendSms;
use App\Models\Group;
use App\Services\Sms;
use App\Models\SenderId;

class ApiEndController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   

    public function sendsms(Request $request)
    {
        $key = request()->key;
        $secrete = request()->secret;
        $auth = DB::table('oauth_clients')->where('id',$key)->where('secret',$secrete)->first();
        
        if($auth){
            // dd($request->numbers);
            foreach(request()->numbers as $contact){
                
                $sms =    Sms::sendSms($request->senderId,$contact,$request->message);   
               
                $contacts = SendSms::create(
                    ['user_id'=>$auth->user_id,
                        'message'=>$request->message,
                        'contact_phone'=>$contact,
                        'sender'=>$request->senderId,
                        'status'=>'DELIVERED',
                    ]
                 );
              } 
              return response()->json([
                'message' => 'SMS send successfully',
             
                'statusCode' => 200,
                
            ], 200);
        }else{
            return response()->json([
                'message' => 'Invalide credentials',
                'statusCode' => 401,
                
            ], 401);
        }
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ApiEnd  $apiEnd
     * @return \Illuminate\Http\Response
     */
    public function show(ApiEnd $apiEnd)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ApiEnd  $apiEnd
     * @return \Illuminate\Http\Response
     */
    public function edit(ApiEnd $apiEnd)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ApiEnd  $apiEnd
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ApiEnd $apiEnd)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ApiEnd  $apiEnd
     * @return \Illuminate\Http\Response
     */
    public function destroy(ApiEnd $apiEnd)
    {
        //
    }
}
