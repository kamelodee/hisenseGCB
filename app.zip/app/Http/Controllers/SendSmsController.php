<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\SendSms;
use App\Models\Group;
use App\Services\Sms;
use App\Models\SenderId;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;


class SendSmsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $groups = Group::where('user_id',Auth::user()->id)->get();
        $senders = SenderId::where('status','ACTIVE')->where('user_id',Auth::user()->id)->get();
        return view('pages/sms/create',compact('groups','senders'));
    }

    public function dashboard(Request $request)
    {
        $status = $request->status;
        $start = $request->start;
        $end = $request->end;
        $textform = $request->textform;
        $smss = SendSms::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->get();
        if(!empty($start) && !empty($end) && !empty($status) && !empty($textform)){
           
        $sms= SendSms::whereBetween('created_at', [$start, $end])
            ->orWhere('status',  $status)
            ->orWhere('contact_phone',  $textform)
            ->orWhere('sender',  $textform)->where('user_id',Auth::user()->id)
            ->paginate(10);
            $groups = Group::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->get();
            $contacts = Contact::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->get();
            return view('dashboard',compact('sms','contacts','groups','smss'));
        }elseif (!empty($start) && !empty($end)){
        //   dd($start);
            $sms= SendSms::whereBetween('created_at', [$start, $end])
                ->paginate(10);
                $groups = Group::orderBy('created_at', 'desc')->get();
                $contacts = Contact::orderBy('created_at', 'desc')->get();
                return view('dashboard',compact('sms','contacts','groups','smss'));
        }elseif(!empty($status) || !empty($textform)){
            
            $sms= SendSms::where('status',  $status)
                ->orWhere('contact_phone',  $textform)
                ->orWhere('sender',  $textform)->where('user_id',Auth::user()->id)
                ->paginate(10);
                $groups = Group::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->get();
                $contacts = Contact::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->get();
                return view('dashboard',compact('sms','contacts','groups','smss'));
        }
        
        else{
            $sms = SendSms::where('user_id',Auth::user()->id)->orderBy('created_at', 'desc')->paginate(10);
    
            $groups = Group::orderBy('created_at', 'desc')->where('user_id',Auth::user()->id)->get();
            $contacts = Contact::orderBy('created_at', 'desc')->where('user_id',Auth::user()->id)->get();
            return view('dashboard',compact('sms','contacts','groups','smss'));
        }
     
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        // dd($request->all());
       
        $this->validate($request, [
            'message'   => 'required',
            'sender'   => 'required',
            
            
        ]);
         $group = Group::find($request->group)->with('smsgroups')->first();
         
        
        //  dd($group->contacts);
         foreach($group->contacts as $contact){
      
        $sms =    Sms::sendSms($request->sender,$contact->phone,$request->message);             
            $contacts = SendSms::create(
                ['user_id'=>Auth::user()->id,
                    'message'=>$request->message,
                    'contact_name'=>$contact->full_name,
                    'contact_phone'=>$contact->phone,
                    'sender'=>$request->sender,
                    'status'=>'DELIVERED',
                ]
             );
            //  sleep(500);
         }
       

        return redirect()->back()->with('success','Message successfully');
    }

    public function contactstore(Request $request)
    {
        // dd($request->all());
       
        $this->validate($request, [
            'message'   => 'required',
            'contacts'   => 'required',
            'sender'   => 'required',
            
            
        ]);
        $contacts = explode(',', request()->contacts);
        // dd( $contacts);
        // dd(request()->all());
         
        
        //  dd($group->contacts);
      foreach($contacts as $contact){
        $sms =    Sms::sendSms($request->sender,$contact,$request->message);   
       
        $contacts = SendSms::create(
            ['user_id'=>Auth::user()->id,
                'message'=>$request->message,
                'contact_phone'=>$contact,
                'sender'=>$request->sender,
                'status'=>'DELIVERED',
            ]
         );
      }
        // $sms =    $transmitter->sendSms($request->message,$request->sender,$contact->phone,['service_type'=>'suhst']);          
          
            //  sleep(500);
         
       

        return redirect()->back()->with('success','Message successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SendSms  $sendSms
     * @return \Illuminate\Http\Response
     */
    public function show(SendSms $sendSms)
    {
        //
    }
    public function developerApi(Request $request)
    {
        $auth = DB::table('oauth_clients')->where('user_id',Auth::user()->id)->first();
       return view('pages/sms/api',compact('auth'));


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SendSms  $sendSms
     * @return \Illuminate\Http\Response
     */
    public function edit(SendSms $sendSms)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SendSms  $sendSms
     * @return \Illuminate\Http\Response
     */
    public function sentsms(Request $request, SendSms $sendSms)
    {
      
       

$url = '148.62.76.42';
    $user = 'admin';
    $pass = '123';

    $params = array(
        "service_type"=> 'suhst',
        "source_addr_ton"=>'',
        "source_addr_npi"=> '',
        "source_addr"=>"HisenseGH",
        "dest_addr_ton"=>'',
        "dest_addr_npi"=>"",
        "destination_addr"=>"+233248907440",
        "esm_class"=>"",
        "protocol_id"=>"",
        "priority_flag"=>"",
        "schedule_delivery_time"=>"",
        "validity_period"=>"",
        "registered_delivery"=>"",
        "replace_if_present_flag"=>"",
        "data_coding"=>"",
        "sm_default_msg_id"=>"",

      );


    $session = curl_init($url);
    curl_setopt ($session, CURLOPT_POST, true);
    curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
    curl_setopt($session, CURLOPT_HEADER, 1);
    curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($session);
    $info = curl_getinfo($session);
    curl_close($session);
    echo $response;
    print_r($info);

    }
    public function update(Request $request, SendSms $sendSms)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SendSms  $sendSms
     * @return \Illuminate\Http\Response
     */
    public function destroy(SendSms $sendSms)
    {
        //
    }
}
