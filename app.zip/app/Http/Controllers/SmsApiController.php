<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SenderId;
use App\Models\SendSms;
use App\Services\Sms;
use App\Models\Group;
use App\Services\SmppTransmitter;
use Illuminate\Support\Facades\Validator;
// use laravel_sms\src\Facades\SMS;
use Illuminate\Support\Facades;
// use ProgLib\Sms\Facades\SMS;
// use Illuminate\Support\Facades;
class SmsApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
  
        //
    }

    public function store(Request $request)
    {
        // dd($request->all());
       
        $this->validate($request, [
            'message'   => 'required',
        ]);
        //  $group = Group::find($request->group)->with('smsgroups')->first();
         
       
        //  dd($group->contacts);
        // $contacts =json_decode($request->contacts);
         foreach($request->contacts as $contact){
         return json_decode($contact->full_name);
        $sms =    Sms::sendSms($request->sender,$contact->phone,$request->message);          
            $contacts = SendSms::create(
                [
                    'message'=>$request->message,
                    'contact_name'=>$contact->full_name,
                    'contact_phone'=>$contact->phone,
                    'sender'=>$request->sender,
                    'status'=>'DELIVERED',
                ]
             );
            //  sleep(500);
         }
       

        return ['message '=>'send'];
    }

    public function contactstore(Request $request)
    {
        // dd($request->all());
       
      
        // dd( $contacts);
        // dd(request()->all());
        // Sms::sendSms();
        $validator = Validator::make($request->all(), [
            'message' => 'required',
            'contact' => 'required',
            'sender' => 'required',
            
        ]);
            if ($validator->fails()) {
                return response()->json([
                    'statusCode' => 401,
                    'error' => $validator->messages()
                ], 200);
            }
         
        //  $transmitter = new Sms->sendSms;
        //  dd($group->contacts);
        Sms::sendSms($request->sender,$request->contact,$request->message);  
        $contacts = SendSms::create(
            [
                'message'=>$request->message,
                'contact_phone'=>$request->contact,
                'sender'=>$request->sender,
                'status'=>'DELIVERED',
            ]
         );
         
    
      
        // $sms =    $transmitter->sendSms($request->message,$request->sender,$contact->phone,['service_type'=>'suhst']);          
          
            //  sleep(500);
         
       

        // return ['message '=>'send'];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
