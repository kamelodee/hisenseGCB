<?php

namespace App\Http\Controllers;

use App\Models\SenderId;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class SenderIdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $senders = SenderId::where('user_id',Auth::user()->id)->get();
        return view('pages/sender_id/index',compact('senders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'   => 'required|max:10'
           ]);
         
        $contact = SenderId::create([
           'user_id'=>Auth::user()->id,
           'name'=>request()->name
        ]
        );
        return redirect()->back()->with('success','Sender ID added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SenderId  $senderId
     * @return \Illuminate\Http\Response
     */
    public function show(SenderId $senderId)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SenderId  $senderId
     * @return \Illuminate\Http\Response
     */
    public function edit(SenderId $senderId)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SenderId  $senderId
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SenderId $senderId)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SenderId  $senderId
     * @return \Illuminate\Http\Response
     */
    public function destroy($senderId)
    {
        SenderId::where('id',$senderId)->delete();
        return redirect()->back();
    }
}
